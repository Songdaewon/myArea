import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.IntBinaryOperator;
import java.util.function.IntSupplier;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.ToDoubleBiFunction;
import java.util.function.ToIntBiFunction;
import java.util.stream.Stream;

public class Main {
	static int idx=0;
	public static void main(String[] args) throws IOException {
		BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
		
		/*1. 람다로 만들기
		Timer t = new Timer(1000, new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				System.out.println("beep");
			}
		});
		*/
		/*
		Timer t = new Timer(1000, (event)->{
			System.out.println("beep");
		});
		
		t.start();
		
		for (int i = 0; i < 1000; i++) {
			try {
				Thread.sleep(1000);                             
			}
			catch (InterruptedException e) {}
		}
		*/
		//2.람다 곱셈 출력
		int x=10;
		int y=20;
		
		IntBinaryOperator ibo = (a,b)->a*b;
		BinaryOperator<Integer> bo = (a,b)->a*b;
		BiConsumer<Integer,Integer> bc = (a,b)->System.out.println("bc: "+a*b);
		BiFunction<Integer,Integer, Integer> bf = (a,b)->a*b;
		ToIntBiFunction<Integer, Integer> tibf = (a,b)->a*b;
		ToDoubleBiFunction<Integer, Integer> tdbf = (a,b)->a*b;
		Supplier<Integer> s = ()->x*y;
		IntSupplier is = ()->x*y;
		Predicate<Integer> p1 = (a)->a>=10;
		Predicate<Integer> p2 = (b)->b>=20;
		BiPredicate<Integer,Integer> ibp = (a,b)->a<b;
		
		Predicate<Integer> p3 = p1.and(p2);
		
		
		System.out.println("IntBiOper: "+ibo.applyAsInt(x, y));
		System.out.println("BiOper<Int>: "+bo.apply(x, y));
		bc.accept(x, y);
		System.out.println("bf: "+bf.apply(x, y));
		System.out.println("tibf: "+tibf.applyAsInt(x, y));
		System.out.println("tdbf: "+tdbf.applyAsDouble(x, y));
		System.out.println("sup: "+s.get());
		System.out.println("Isup: "+is.getAsInt());
		System.out.println(p1.test(x));
		
		System.out.println("평균 신장 : " + average(Person.persons,p->p.getHeight()));
        System.out.println("평균 체중 : " + average(Person.persons,p->p.getWeight()));
        
        //3.ArrayList
        /*
        List<Integer> list = new ArrayList<>();
        while(true) {
        	System.out.print("점수를 입력: ");
        	int n = Integer.parseInt(br.readLine());
        	if(n<0)
        		break;
        	list.add(n);	
        }
        System.out.println("전체 학생: "+list.size());
        System.out.print("학생들의 성적: ");
        list.forEach(l->System.out.print(l+" "));
        System.out.println();
        list.forEach(l->{
        	String score;
        	if(l>=81) {
        		score="A";
        	}
        	else if(l>=71) {
        		score="B";
        	}
        	else if(l>=61) {
        		score="C";
        	}
        	else {
        		score="F";
        	}
        	System.out.println((idx++)+"번 학생의 성적은 68점이며 등급은 "+score+"다.");
        });
        */
        
        //4.스트림
        Stream<String> stream = Stream.of("갈매기", "나비","라마", "다람쥐","갈치" );
        stream
        .sorted(Comparator.reverseOrder())
        .skip(4)
        .forEach(str->System.out.println(str));
        
        
        
        
    }

    public static double average(List<Person> l,Function<Person, Integer> f) {
		
    	double sum=0;
    	int count=0;
    	
    	for(Person p:l) {
    		sum+=f.apply(p);
    		count++;
    	}
    	return sum/count;
    }
   
	
}
class Person {
    private String name;
    private int height, weight;

    public Person(String name, int height, int weight) {
        this.name = name;
        this.height = height;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public int getHeight() {
        return height;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return name + "(" + height + ", " + weight + ")";
    }

    static List<Person> persons = Arrays.asList(
            new Person("황진이", 160, 45), new Person("이순신", 180, 80),
            new Person("김삿갓", 175, 65), new Person("홍길동", 170, 68),
            new Person("배장화", 155, 48)
    );
}




















