package net.skhu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E2023140791ApplicationTests {

	@Test
	void contextLoads() {
	}

}
