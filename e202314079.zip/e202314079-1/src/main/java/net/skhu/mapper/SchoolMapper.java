package net.skhu.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import net.skhu.dto.School;
import net.skhu.dto.building;

@Mapper
public interface SchoolMapper {
	@Select("""
			select *
			from room r join building b on r.buildingId=b.id
			where r.roomName like #{name};
			""")
	List<School> findByName(String name);

	@Select("""
			select *
			from room
			where id=#{id};
			""")
	School findById(int id);

	@Select("""
			select *
			from building;
			""")
	List<building> findAll();

	@Update("""
			update room
			set
			roomName=#{roomName},
			capacity=#{capacity},
			buildingId=#{buildingId},
			roomType = #{roomType}
			where id=#{id};
			""")
	void update(School room);

	@Delete("""
			delete from room where id=#{id}
			""")
	void delete(int id);
}
