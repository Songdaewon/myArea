package net.skhu.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import net.skhu.dto.School;
import net.skhu.mapper.SchoolMapper;
import net.skhu.model.SchoolEdit;



@Controller
public class SchoolController {
	@Autowired SchoolMapper sm;
	ModelMapper mm = new ModelMapper();

	@GetMapping("list")
	public String list(Model model, @RequestParam(value="name",defaultValue = "")String name) {
		List<School> s = sm.findByName(name+"%");
		model.addAttribute("school",s);
		model.addAttribute("name",name);

		return "list";
	}
	@GetMapping("edit")
	public String edit(Model model, @RequestParam("id")int id) {
		SchoolEdit se = new SchoolEdit();
		School s = sm.findById(id);
		se=mm.map(s, SchoolEdit.class);

		model.addAttribute("build",sm.findAll());
		model.addAttribute("se",se);

		return "edit";
	}
	@PostMapping(value="edit",params="a=a")
	public String postMethodName(Model model, SchoolEdit se) {
		School s = mm.map(se, School.class);
		sm.update(s);

		return "redirect:list";
	}
	@PostMapping(value="edit",params="b=b")
	public String postMethodName1(Model model, SchoolEdit se) {
		sm.delete(se.getId());

		return "redirect:list";
	}

	@GetMapping("create")
	public String getMethodName(Model model) {
		return new String();
	}




}
