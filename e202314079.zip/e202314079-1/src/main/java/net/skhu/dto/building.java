package net.skhu.dto;

public class building {
	int id;
	String building;
}
