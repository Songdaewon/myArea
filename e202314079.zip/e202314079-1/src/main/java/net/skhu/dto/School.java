package net.skhu.dto;

import lombok.Data;

@Data
public class School {
	int id;
	String roomName;
	int capacity;
	int buildingId;
	String roomType;
	String buildingName;
}
