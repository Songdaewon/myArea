package net.skhu.model;

import lombok.Data;

@Data
public class SchoolEdit {
	int id;
	String roomName;
	int capacity;
	int buildingId;
	String roomType;
}
