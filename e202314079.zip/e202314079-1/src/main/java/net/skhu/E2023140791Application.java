package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E2023140791Application {

	public static void main(String[] args) {
		SpringApplication.run(E2023140791Application.class, args);
	}

}
